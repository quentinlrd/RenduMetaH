package jobshop.solvers;

import jobshop.Instance;
import jobshop.Result;
import jobshop.Solver;
import jobshop.encodings.ResourceOrder;
import jobshop.encodings.Task;

import java.util.ArrayList;
import java.util.List;

public class DescentSolver implements Solver {

    /** A block represents a subsequence of the critical path such that all tasks in it execute on the same machine.
     * This class identifies a block in a ResourceOrder representation.
     *
     * Consider the solution in ResourceOrder representation
     * machine 0 : (0,1) (1,2) (2,2)
     * machine 1 : (0,2) (2,1) (1,1)
     * machine 2 : ...
     *
     * The block with : machine = 1, firstTask= 0 and lastTask = 1
     * Represent the task sequence : [(0,2) (2,1)]
     *
     * */
    static class Block {
        /** machine on which the block is identified */
        final int machine;
        /** index of the first task of the block */
        final int firstTask;
        /** index of the last task of the block */
        final int lastTask;

        Block(int machine, int firstTask, int lastTask) {
            this.machine = machine;
            this.firstTask = firstTask;
            this.lastTask = lastTask;
        }
    }

    /**
     * Represents a swap of two tasks on the same machine in a ResourceOrder encoding.
     *
     * Consider the solution in ResourceOrder representation
     * machine 0 : (0,1) (1,2) (2,2)
     * machine 1 : (0,2) (2,1) (1,1)
     * machine 2 : ...
     *
     * The swam with : machine = 1, t1= 0 and t2 = 1
     * Represent inversion of the two tasks : (0,2) and (2,1)
     * Applying this swap on the above resource order should result in the following one :
     * machine 0 : (0,1) (1,2) (2,2)
     * machine 1 : (2,1) (0,2) (1,1)
     * machine 2 : ...
     */
    static class Swap {
        // machine on which to perform the swap
        final int machine;
        // index of one task to be swapped
        final int t1;
        // index of the other task to be swapped
        final int t2;

        Swap(int machine, int t1, int t2) {
            this.machine = machine;
            this.t1 = t1;
            this.t2 = t2;
        }

        /** Apply this swap on the given resource order, transforming it into a new solution. */
        public void applyOn(ResourceOrder order) {
            Task t = order.tasksByMachine[this.machine][t1];
            order.tasksByMachine[this.machine][t1] = order.tasksByMachine[this.machine][t2];
            order.tasksByMachine[this.machine][t2] = t;
        }
    }


    @Override
    public Result solve(Instance instance, long deadline) {
        boolean upgrade = true ;
        Solver greedyEST_LRPT = new GreedySolver(GreedySolver.priorityRules.SPT);
        ResourceOrder order = new ResourceOrder(greedyEST_LRPT.solve(instance, deadline).schedule);
        int min = Integer.MAX_VALUE ;
        int index_min= -1 ;
        while(upgrade && (deadline-System.currentTimeMillis() > 1)){
            List<Block> block = blocksOfCriticalPath(order);
            ArrayList<ResourceOrder> neighbors =  new ArrayList<>() ;
            for (int i = 0 ; i<block.size() ; i++){
                for( int j = 0 ; j<neighbors(block.get(i)).size(); j++) {
                    ResourceOrder new_voisin = order.copy();
                    neighbors(block.get(i)).get(j).applyOn(new_voisin);
                    neighbors.add(new_voisin);
                }
            }
            min = Integer.MAX_VALUE;
            index_min = -1 ;

            for(int i = 0 ;i < neighbors.size(); i++){
                if(neighbors.get(i).toSchedule().makespan()<min){
                    min = neighbors.get(i).toSchedule().makespan() ;
                    index_min = i ;
                }
            }
            upgrade = (min <= order.toSchedule().makespan());
            if (upgrade) {
                order=neighbors.get(index_min).copy();
            }

        }
        if (deadline-System.currentTimeMillis() < 1 ){
            return new Result(instance,order.toSchedule(), Result.ExitCause.Timeout);
        }
        else {
            return new Result(instance,order.toSchedule(), Result.ExitCause.ProvedOptimal) ;
        }


    }

    /** Returns a list of all blocks of the critical path. */
    List<Block> blocksOfCriticalPath(ResourceOrder order) {
        List<Task> tasklist = order.toSchedule().criticalPath() ;
        List<Block> blocklist = new ArrayList<>() ;
        Boolean new_block = false ;
        Task t_prev = tasklist.get(0) ;

        for(int i = 1 ; i<tasklist.size() ; i++){
            while(i<tasklist.size() && order.instance.machine(t_prev)==order.instance.machine(tasklist.get(i)) ){
                new_block = true ;
                i++ ;
            }
            if(new_block){
                int i1 =0;
                int i2 =0;

                while((i1<order.instance.numJobs)&& !(order.tasksByMachine[order.instance.machine(t_prev)][i1].equals(t_prev))){
                    i1++;
                }
                while((i2<order.instance.numJobs)&& !(order.tasksByMachine[order.instance.machine(tasklist.get(i-1))][i2].equals(tasklist.get(i-1)))){
                    i2++;
                }
                Block b = new Block(order.instance.machine(t_prev),i1,i2);
                blocklist.add(b);
                new_block = false ;
            }
            if(i<tasklist.size()){
                t_prev = tasklist.get(i) ;
            }

        }

        return blocklist ;
    }

    /** For a given block, return the possible swaps for the Nowicki and Smutnicki neighborhood */
    List<Swap> neighbors(Block block) {
        List<Swap> swap = new ArrayList<>();
        if(block.firstTask+1==block.lastTask){
            swap.add(new Swap(block.machine,block.firstTask,block.lastTask));
        }
        else{
            swap.add(new Swap(block.machine,block.firstTask,block.firstTask+1));
            swap.add(new Swap(block.machine,block.lastTask-1,block.lastTask));
        }
        return swap ;
    }

}
