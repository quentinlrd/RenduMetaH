package jobshop.solvers;

import jobshop.Instance;
import jobshop.Result;
import jobshop.Solver;
import jobshop.encodings.ResourceOrder;
import jobshop.encodings.Task;

import java.util.ArrayList;
import java.util.Arrays;


public class GreedySolver implements Solver {
    public enum priorityRules {
        SPT,
        LRPT,
        EST_LRPT,
        EST_SPT
    }
    private final priorityRules rule ;
    public GreedySolver(priorityRules rule) {
        super();
        this.rule = rule;
    }
    @Override
    public Result solve(Instance instance, long deadline) {
        ResourceOrder rO = new ResourceOrder(instance);
        int[] startingTimeMachine = new int[rO.instance.numMachines];
        int[] startingTimeJobs = new int[rO.instance.numJobs];
        ArrayList<Task> realisable = new ArrayList<Task>();
        int start_time;
        // Initialisation des variables
        Arrays.fill(startingTimeJobs,0);
        Arrays.fill(startingTimeMachine,0);

        for (int j =0; j < instance.numJobs; j++){
            realisable.add(new Task(j,0));
        }


        Task t;
        while (!realisable.isEmpty()) {
            switch (this.rule) {
                case SPT:
                    t = this.sortSPT(rO,realisable);
                    break ;
                case LRPT:
                    t = this.sortLRPT(rO,realisable);
                    break ;
                case EST_SPT:
                    t = this.sortEST_SPT(rO,realisable,startingTimeMachine,startingTimeJobs);
                    break;
                case EST_LRPT:
                    t= this.sortEST_LRPT(rO,realisable,startingTimeMachine,startingTimeJobs);
                    break;

                default :
                    t = realisable.get(0); // Uniquement pour eviter une erreur d'initialisation de t
            }
            int num_instance = instance.machine(t) ;
            rO.tasksByMachine[num_instance][rO.nextFreeSlot[num_instance]] = t;
            rO.nextFreeSlot[instance.machine(t)]++;
            start_time = Math.max(startingTimeMachine[instance.machine(t)], startingTimeJobs[t.job]);
            startingTimeMachine[instance.machine(t)] = start_time + instance.duration(t);
            startingTimeJobs[t.job] = start_time + instance.duration(t);
            realisable.remove(t);
            if (t.task + 1 < instance.numTasks) {
                Task new_t = new Task(t.job, t.task + 1);
                realisable.add(new_t);
            }
        }
        return new Result(instance,rO.toSchedule(),Result.ExitCause.ProvedOptimal) ;
    }



    public Task sortSPT(ResourceOrder rO ,ArrayList<Task> realisable){
        Task t = realisable.get(0) ;
        for ( int i=1 ; i< realisable.size() ; i++) {
            Task itask = realisable.get(i) ;
            if(rO.instance.duration(itask)<rO.instance.duration(t)){
                t = itask ;
            }
        }
        return t ;
    }

    public Task sortLRPT(ResourceOrder rO ,ArrayList<Task> realisable){
        int returnedIndex = 0 ;
        int timeJob ;
        int longestJob = -1;
        for(int i=0 ; i < realisable.size() ; i++){
            timeJob = 0 ;
            for(int j = realisable.get(i).task ; j<rO.instance.numTasks ; j++) {
                timeJob+=rO.instance.duration(realisable.get(i).job,j);
            }
            if (longestJob == -1){
                longestJob = timeJob ;
            }
            else if (timeJob>longestJob){
                returnedIndex=i;
            }
        }
        return realisable.get(returnedIndex) ;
    }

    public Task sortEST_SPT(ResourceOrder rO, ArrayList<Task> realisable, int[] startingTimeMachine, int[] startingTimeJob){
        ArrayList<Task> ESTList = new ArrayList<>() ;
        int task_start ;
        int earliest_start = Integer.MAX_VALUE;
        for ( int i=0 ; i< realisable.size() ; i++) {
            Task itask = realisable.get(i);
            task_start = Math.max(startingTimeJob[itask.job], startingTimeMachine[rO.instance.machine(itask)]);
            if (task_start < earliest_start) {
                earliest_start = task_start;
                ESTList.clear();
                ESTList.add(itask);
            } else if (task_start == earliest_start) {
                ESTList.add(itask);
            }
        }
            return sortSPT(rO,ESTList) ;

    }

    public Task sortEST_LRPT(ResourceOrder rO, ArrayList<Task> realisable, int[] startingTimeMachine, int[] startingTimeJob){
        ArrayList<Task> ESTList = new ArrayList<>() ;
        int task_start ;
        int earliest_start = Integer.MAX_VALUE;
        for ( int i=0 ; i< realisable.size() ; i++) {
            Task itask = realisable.get(i);
            task_start = Math.max(startingTimeJob[itask.job], startingTimeMachine[rO.instance.machine(itask)]);
            if (task_start < earliest_start) {
                earliest_start = task_start;
                ESTList.clear();
                ESTList.add(itask);
            } else if (task_start == earliest_start) {
                ESTList.add(itask);
            }
        }
        return sortLRPT(rO,ESTList) ;

    }

    }