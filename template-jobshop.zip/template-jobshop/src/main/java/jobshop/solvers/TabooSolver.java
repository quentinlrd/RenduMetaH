package jobshop.solvers;

import jobshop.Instance;
import jobshop.Result;
import jobshop.Solver;

import jobshop.encodings.ResourceOrder;
import jobshop.encodings.Task;

import java.util.ArrayList;

import java.util.List;

public class TabooSolver implements Solver{

    public int maxIter, dureeTaboo ;

    public TabooSolver(int maxIter, int dureeTaboo) {
        super() ;
        this.maxIter = maxIter ;
        this.dureeTaboo = dureeTaboo ;

    }
    /** A block represents a subsequence of the critical path such that all tasks in it execute on the same machine.
     * This class identifies a block in a ResourceOrder representation.
     *
     * Consider the solution in ResourceOrder representation
     * machine 0 : (0,1) (1,2) (2,2)
     * machine 1 : (0,2) (2,1) (1,1)
     * machine 2 : ...
     *
     * The block with : machine = 1, firstTask= 0 and lastTask = 1
     * Represent the task sequence : [(0,2) (2,1)]
     *
     * */
    static class Block {
        /** machine on which the block is identified */
        final int machine;
        /** index of the first task of the block */
        final int firstTask;
        /** index of the last task of the block */
        final int lastTask;

        Block(int machine, int firstTask, int lastTask) {
            this.machine = machine;
            this.firstTask = firstTask;
            this.lastTask = lastTask;
        }
    }

    /**
     * Represents a swap of two tasks on the same machine in a ResourceOrder encoding.
     *
     * Consider the solution in ResourceOrder representation
     * machine 0 : (0,1) (1,2) (2,2)
     * machine 1 : (0,2) (2,1) (1,1)
     * machine 2 : ...
     *
     * The swam with : machine = 1, t1= 0 and t2 = 1
     * Represent inversion of the two tasks : (0,2) and (2,1)
     * Applying this swap on the above resource order should result in the following one :
     * machine 0 : (0,1) (1,2) (2,2)
     * machine 1 : (2,1) (0,2) (1,1)
     * machine 2 : ...
     */
    static class Swap {
        // machine on which to perform the swap
        final int machine;
        // index of one task to be swapped
        final int t1;
        // index of the other task to be swapped
        final int t2;

        Swap(int machine, int t1, int t2) {
            this.machine = machine;
            this.t1 = t1;
            this.t2 = t2;
        }

        /** Apply this swap on the given resource order, transforming it into a new solution. */
         public void applyOn(ResourceOrder order) {

            Task t = order.tasksByMachine[this.machine][t1];
            order.tasksByMachine[this.machine][t1] = order.tasksByMachine[this.machine][t2];
            order.tasksByMachine[this.machine][t2] = t;

        }
    }

    @Override
    public Result solve(Instance instance, long deadline) {
        boolean bool  ;
        Solver greedyEST_LRPT = new GreedySolver(GreedySolver.priorityRules.EST_LRPT);
        ResourceOrder s_etoile = new ResourceOrder(greedyEST_LRPT.solve(instance, deadline).schedule);
        ResourceOrder s_voisin = s_etoile.copy() ;
        int tache1 = -1 ;
        int tache2 = -1 ;
        int[][] sTaboo = new int[instance.numJobs * instance.numTasks][instance.numJobs * instance.numTasks];
        for (int i = 0; i < (instance.numJobs * instance.numTasks); i++) {
            for(int j =0 ; j<(instance.numJobs*instance.numTasks);j++){
                sTaboo[i][j]=0;
            }
        }
        int iter = 0;
        int bestMakespan = s_etoile.toSchedule().makespan() ;
        while (iter < this.maxIter && (deadline - System.currentTimeMillis() > 1)) {
            iter++;
            bool = false ;
            ResourceOrder s_current = s_voisin.copy();
            int makespan_voisin = Integer.MAX_VALUE;
            List<Block> blocks = blocksOfCriticalPath(s_current);
            for(int i = 0 ; i< blocks.size() ; i++){
                for( Swap swap :neighbors(blocks.get(i))) {
                    int task1 = s_current.tasksByMachine[swap.machine][swap.t1].task + s_current.tasksByMachine[swap.machine][swap.t1].job * s_etoile.toSchedule().pb.numTasks;
                    int task2 = s_current.tasksByMachine[swap.machine][swap.t2].task + s_current.tasksByMachine[swap.machine][swap.t2].job * s_etoile.toSchedule().pb.numTasks;
                    if (sTaboo[task1][task2] < iter) {
                        bool = true;
                        ResourceOrder voisin = s_current.copy();
                        swap.applyOn(voisin);
                        int makespan_swap = voisin.toSchedule().makespan();
                        if (makespan_swap < makespan_voisin) {
                            tache1 = s_current.tasksByMachine[swap.machine][swap.t1].task + s_current.tasksByMachine[swap.machine][swap.t1].job * s_etoile.toSchedule().pb.numTasks;
                            tache2 = s_current.tasksByMachine[swap.machine][swap.t2].task + s_current.tasksByMachine[swap.machine][swap.t2].job * s_etoile.toSchedule().pb.numTasks;
                            makespan_voisin = makespan_swap;
                            s_voisin = voisin.copy();
                            if (makespan_voisin < bestMakespan) {
                                bestMakespan = makespan_voisin;
                                s_etoile = voisin.copy();
                            }
                        }
                    }
                }
            }

            if(bool){
                sTaboo[tache1][tache2] =iter+this.dureeTaboo;

            }
        }
        if (deadline-System.currentTimeMillis() < 1 ){
            return new Result(instance,s_etoile.toSchedule(), Result.ExitCause.Timeout);
        }
        else if (iter>=this.maxIter){
            return new Result(instance,s_etoile.toSchedule(), Result.ExitCause.Blocked);
        }
        else {
            return new Result(instance,s_etoile.toSchedule(), Result.ExitCause.ProvedOptimal) ;
        }
    }

    /** Returns a list of all blocks of the critical path. */
    List<Block> blocksOfCriticalPath(ResourceOrder order) {
        List<Task> tasklist = order.toSchedule().criticalPath() ;
        List<Block> blocklist = new ArrayList<>() ;
        Boolean new_block = false ;
        Task t_prev = tasklist.get(0) ;

        for(int i = 1 ; i<tasklist.size() ; i++){
            while(i<tasklist.size() && order.instance.machine(t_prev)==order.instance.machine(tasklist.get(i)) ){
                new_block = true ;
                i++ ;
            }
            if(new_block){
                int i1 =0;
                int i2 =0;

                while((i1<order.instance.numJobs)&& !(order.tasksByMachine[order.instance.machine(t_prev)][i1].equals(t_prev))){
                    i1++;
                }
                while((i2<order.instance.numJobs)&& !(order.tasksByMachine[order.instance.machine(tasklist.get(i-1))][i2].equals(tasklist.get(i-1)))){
                    i2++;
                }
               Block b = new Block(order.instance.machine(t_prev),i1,i2);
                blocklist.add(b);
                new_block = false ;
            }
            if(i<tasklist.size()){
                t_prev = tasklist.get(i) ;
            }

        }

        return blocklist ;
    }


    List<Swap> neighbors(Block block) {
        List<Swap> swap = new ArrayList<>();
        if(block.firstTask+1==block.lastTask){
            swap.add(new Swap(block.machine,block.firstTask,block.lastTask));
        }
        else{
            swap.add(new Swap(block.machine,block.firstTask,block.firstTask+1));
            swap.add(new Swap(block.machine,block.lastTask-1,block.lastTask));
        }
        return swap ;
    }

    }

